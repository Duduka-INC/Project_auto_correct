package com.ak.planner;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    private BottomSheetDialog mBottomSheetDialog; //переменная класса BottomSheetDialog (маленькое окошко)
    private View sheetView; //окно
    private ProgressBar progressBar; //полоса загрузки
    private Button pickfile; //кнопка "Загрузить файл"
    private Button picktext; //кнопка "Открыть редактор"
    private CheckBox checkBox; //галочка

    @Override
    protected void onCreate(Bundle savedInstanceState) { //функция, которая вызывается при открытии приложения
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); //настраиваем вид главной формы (активности)

        Toolbar mActionBarToolbar = (Toolbar) findViewById(R.id.toolbar_actionbar); //зеленая прямоугольная панель
        setSupportActionBar(mActionBarToolbar); //выводим верхнюю зеленую прямоугольную панель

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED || //https://developer.android.com/training/permissions/requesting
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) { //проверяем разрешения на чтение и запись в память
            mBottomSheetDialog = new BottomSheetDialog(MainActivity.this); //инициализируем диалоговое нижнее окно (стекло)
            sheetView = getLayoutInflater().inflate(R.layout.bottom_dialog_notification, null); //из содержимого layout-файла создаем View-элемент (инициализируем рисунок)
            mBottomSheetDialog.setContentView(sheetView); //отрисовываем компоненты на экране (приклеиваем рисунок на стекло)
            mBottomSheetDialog.setCancelable(false); //запрещаем закрывать окно пользователю (нужно же дать разрешения приложению на чтение и запись в хранилище!)
            mBottomSheetDialog.show(); //выводим диалоговое нижнее окно на экран

            Button iRequest = sheetView.findViewById(R.id.iRequest); //инициализируем кнопку (ищем ее в рисунке)
            iRequest.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) { //настраиваем прослушиватель кнопки "ЗАПРОСИТЬ РАЗРЕШЕНИЯ" (обрабатываем нажатия на нее)
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                        ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                    && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) //проверяем, есть ли разрешения на чтение и запись данных в память устройства
                    {
                        mBottomSheetDialog.setCancelable(true); //разрешаем закрывать окно
                        mBottomSheetDialog.dismiss(); //закрываем окно из кода
                    }
                }
            });
        }

        // FAB (центральная кнопка круглая с карандашиком)
        final FloatingActionButton fab = findViewById(R.id.fab); //инициализируем кнопку FAB
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) { //настраиваем прослушиватель кнопки
                //выводим диалоговое окно выбора файла для исправления
                mBottomSheetDialog = new BottomSheetDialog(MainActivity.this);
                sheetView = getLayoutInflater().inflate(R.layout.bottom_dialog_constructor_setup, null);
                mBottomSheetDialog.setContentView(sheetView);
                mBottomSheetDialog.show();

                checkBox = sheetView.findViewById(R.id.checkbox1); //инициализируем галочку
                progressBar = sheetView.findViewById(R.id.progressBar); //инициализируем полосу загрузки
                progressBar.setVisibility(ProgressBar.INVISIBLE); //делаем полосу невидимой

                pickfile = sheetView.findViewById(R.id.pickfile); //инициализируем кнопку "ЗАГРУЗИТЬ ФАЙЛ"
                pickfile.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) { //делаем прослушиватель кнопки
                        progressBar.setVisibility(ProgressBar.VISIBLE); //делаем кнопку видимой
                        pickfile.setEnabled(false); //выключаем кнопку, дабы пользователь не нажимал ее по сто раз во время открытия проводника

                        openExplorer(); //вызываем проводник
                    }
                });

                picktext = sheetView.findViewById(R.id.picktext); //инициализируем кнопку "ОТКРЫТЬ РЕДАКТОР"
                picktext.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) { //делаем прослушиватель кнопки
                        mBottomSheetDialog.dismiss(); //закрываем диалоговое окно
                        mBottomSheetDialog = new BottomSheetDialog(MainActivity.this); //открываем другое диалоговое окно с редактором
                        sheetView = getLayoutInflater().inflate(R.layout.bottom_dialog_text, null);
                        mBottomSheetDialog.setContentView(sheetView);
                        mBottomSheetDialog.show();

                        Button apply = sheetView.findViewById(R.id.apply); //инициализируем кнопку
                        apply.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                //открываем окно редактора
                                TextInputEditText textinput = sheetView.findViewById(R.id.textEditDialog); //инициализируем textedit (поле, куда можно писать текст)
                                String text = textinput.getText().toString(); //записываем прочитанный текст из файла в переменную
                                //исправляем все места со знаками препинания (если такие, конечно, будут)
                                String newText = text.replaceAll("[,.!?;:]", "$0 ").replaceAll("\\s+", " ").replaceAll("\\s+(?=\\p{Punct})", "");
                                textinput.setText(newText); //меняем текст поля на исправленный текст

                                //копируем в буфер обмена
                                android.content.ClipboardManager clipboard = (android.content.ClipboardManager) getApplicationContext().getSystemService(Context.CLIPBOARD_SERVICE); //инициализируем буфер обмена
                                android.content.ClipData clip = android.content.ClipData.newPlainText("Copied Text", newText); //создаем новую запись
                                clipboard.setPrimaryClip(clip); //добавляем запись в буфер обмена
                            }
                        });

                        Button cancel = sheetView.findViewById(R.id.cancel); //инициализиурем кнопку
                        cancel.setOnClickListener(new View.OnClickListener() { //делаем прослушиватель кнопки
                            @Override
                            public void onClick(View view) {
                                mBottomSheetDialog.dismiss(); //закрываем диалоговое окно
                            }
                        });
                    }
                });


            }
        });
    }

    private static final int READ_REQUEST_CODE = 42;



    public void openExplorer() { //функция проводника
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); //инициализируем интент (окно проводника)
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/plain"); //говорим проводнику, что нам нужен текстовый файл .txt, остальные не подойдут

        startActivityForResult(intent, READ_REQUEST_CODE); //открываем проводник
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent resultData) {
        super.onActivityResult(requestCode, resultCode, resultData);
        if (requestCode == READ_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            Uri selectedfile = null;
            if (resultData != null)
                selectedfile = resultData.getData();

            //конструкция try-catch, если возникнут исключения (файл не читается), программа НЕ вылетит
            try (InputStream inputStream = getContentResolver().openInputStream(selectedfile)) { //создаем поток данных для входа из файла
                BufferedReader br = new BufferedReader(new InputStreamReader(inputStream)); //создаем читалку потока данных
                StringBuilder sb = new StringBuilder(); //создаем переменную построения строки
                String line = br.readLine();
                while (line != null) { //читаем файл построчно с переносом по строкам
                    sb.append(line);
                    sb.append(System.lineSeparator());
                    line = br.readLine();
                }
                String text = sb.toString(); //записываем прочитанный текст из файла в переменную

                //исправляем все места со знаками препинания (если такие, конечно, будут)
                String newText = text.replaceAll("[,.!?;:]", "$0 ").replaceAll("\\s+", " ").replaceAll("\\s+(?=\\p{Punct})", "");


                //просто проверяем, совпадают ли старый текст и новый исправленный текст
                if (text.contains(newText)) //совпадают, все хорошо, выводим окно, что исправления не требуются
                {
                    mBottomSheetDialog.dismiss();
                    mBottomSheetDialog = new BottomSheetDialog(MainActivity.this);
                    sheetView = getLayoutInflater().inflate(R.layout.bottom_dialog_fileok, null);
                    mBottomSheetDialog.setContentView(sheetView);
                    mBottomSheetDialog.show();
                }
                else //не совпадают, выводим окно, что были найдены ошибки
                {
                    mBottomSheetDialog.dismiss();
                    mBottomSheetDialog = new BottomSheetDialog(MainActivity.this);
                    sheetView = getLayoutInflater().inflate(R.layout.bottom_dialog_filenonok, null);
                    mBottomSheetDialog.setContentView(sheetView);
                    mBottomSheetDialog.show();
                }

                if (checkBox.isChecked()) { //проверяем, отмечена ли галочка: если отмечена, то исправляем файл (записываем в него исправленный текст)
                    OutputStream outputStream = getContentResolver().openOutputStream(selectedfile); //создаем поток вывода данных для файла (текст для печати)
                    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(outputStream)); //создаем переменную записи данных в файл из потока (принтер)
                    writer.write(newText); //записываем изменения (печатаем документ)
                    writer.close(); //закрываем записывалку
                }
            } catch (IOException e) {
                e.printStackTrace(); //если произошла ошибка (исключение), то выводим в логи ошибку
            }

            //mBottomSheetDialog.dismiss();
            progressBar.setVisibility(ProgressBar.INVISIBLE); //делаем полосу загрузки невидимой
        }
        else //если пользователь вышел из проводника, так ничего и не выбрав (нажал на кнопку "назад")
        {
            pickfile.setEnabled(true); //включаем кнопку снова
            progressBar.setVisibility(ProgressBar.INVISIBLE); //делаем полосу загрузки невидимой
        }
    }
}